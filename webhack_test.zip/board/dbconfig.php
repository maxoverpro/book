<?php
 $host = 'localhost';
 $dbname = 'webhack';
 $user = 'root';
 $passwd = 'admin';
?>
